tester module
=============

.. automodule:: tester
    :members:
    :undoc-members:
    :show-inheritance:
